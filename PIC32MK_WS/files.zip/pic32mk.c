/*
 * pic32mk.c — QEMU board model for Microchip PIC32MK GPK/MCM with CAN FD
 *
 * Implements Phase 1: CPU instantiation, physical memory map, reset module
 * stub, and SFR fallback I/O handler.
 *
 * Register sources (DS60001519E):
 *   Memory map:     §4, Figures 4-1/4-2, Table 4-2  (pp. 70-73)
 *   Boot alias:     §4, Table 4-1                   (p. 72)
 *   Reset module:   §7, Table 7-1, Registers 7-1/7-2 (pp. 113-117)
 *   EVIC:           §8, Register 8-1                 (p. 159)
 *   CP0 config:     §3, Registers 3-1 through 3-6    (pp. 55-61)
 *   Exception vec:  §8, Table 8-2                    (p. 124)
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

#include "qemu/osdep.h"
#include "qemu/units.h"
#include "qemu/log.h"
#include "qemu/error-report.h"
#include "qapi/error.h"
#include "hw/boards.h"
#include "hw/loader.h"
#include "hw/mips/mips.h"
#include "hw/mips/cpudevs.h"
#include "hw/qdev-properties.h"
#include "hw/sysbus.h"
#include "sysemu/sysemu.h"
#include "sysemu/reset.h"
#include "exec/address-spaces.h"
#include "target/mips/cpu.h"
#include "hw/mips/pic32mk.h"

/* ------------------------------------------------------------------ *
 *  Board state container                                              *
 * ------------------------------------------------------------------ */
struct PIC32MKState {
    MachineState    parent_obj;

    MIPSCPU        *cpu;

    /* Physical memory regions */
    MemoryRegion    ram;
    MemoryRegion    flash;
    MemoryRegion    boot_flash1;
    MemoryRegion    boot_flash2;

    /*
     * Boot alias regions — DS60001519E §4, Table 4-1 (p. 72)
     *
     * The lower boot alias (physical 0x1FC0_0000) is where the MIPS
     * reset vector (KSEG1 0xBFC0_0000) actually points.  On real
     * hardware the CRU routes it to whichever BF bank has the higher
     * TSEQ value.  For emulation we alias it unconditionally to BF1.
     *
     * The upper boot alias (0x1FC2_0000) mirrors the other bank.
     */
    MemoryRegion    boot_lower_alias;
    MemoryRegion    boot_upper_alias;

    /*
     * SFR container — 1 MB window at physical 0x1F80_0000.
     * Individual peripheral MemoryRegions are added as sub-regions
     * of this container in Phases 2/3/4.  The sfr_stub fallback
     * sits at priority -1 so real peripheral regions override it.
     */
    MemoryRegion    sfr;
    MemoryRegion    sfr_stub;

    /*
     * Reset module registers — DS60001519E §7, Table 7-1 (p. 114)
     * Implemented inline here for Phase 1.  Will be split to its
     * own file (pic32mk_reset.c) in Phase 2 if it grows.
     */
    MemoryRegion    reset_regs;
    uint32_t        rcon;       /* 0xBF801240 — reset cause flags   */
    uint32_t        rswrst;     /* 0xBF801250 — sw reset trigger    */
    uint32_t        rnmicon;    /* 0xBF801260 — NMI control         */
    uint32_t        pwrcon;     /* 0xBF801270 — power control       */

    /*
     * EVIC stub — just INTCON for Phase 1 so firmware that reads
     * INTCON on startup doesn't hit the generic stub path.
     * Full EVIC model comes in Phase 2.
     */
    MemoryRegion    evic_stub;
    uint32_t        intcon;     /* 0xBF810000 — interrupt control   */

    /* Device variant (selects RAM/Flash sizes) */
    PIC32MKVariant  variant;
};

#define TYPE_PIC32MK_MACHINE  TYPE_PIC32MK_MACHINE   /* from header */
OBJECT_DECLARE_SIMPLE_TYPE(PIC32MKState, PIC32MK_MACHINE)

/* ------------------------------------------------------------------ *
 *  SFR fallback stub — catches any unimplemented SFR access          *
 * ------------------------------------------------------------------ */

/*
 * pic32mk_sfr_stub_read / _write
 *
 * These log every unimplemented SFR hit via LOG_UNIMP.  Running QEMU
 * with -d unimp pipes these to stderr, giving you the exact offset of
 * every peripheral register the firmware touches — use this output to
 * drive the Phase 2 implementation queue.
 *
 * Returns 0 on read (safe default for most status/flag registers).
 */
static uint64_t pic32mk_sfr_stub_read(void *opaque, hwaddr offset,
                                      unsigned size)
{
    /*
     * Compute the virtual address the firmware actually accessed.
     * SFR KSEG1 base is 0xBF800000 (physical 0x1F800000).
     */
    qemu_log_mask(LOG_UNIMP,
                  "pic32mk: SFR read  @ phys 0x1F8%05" HWADDR_PRIx
                  " (virt 0xBF8%05" HWADDR_PRIx ") size=%u — unimplemented\n",
                  offset, offset, size);
    return 0;
}

static void pic32mk_sfr_stub_write(void *opaque, hwaddr offset,
                                   uint64_t value, unsigned size)
{
    qemu_log_mask(LOG_UNIMP,
                  "pic32mk: SFR write @ phys 0x1F8%05" HWADDR_PRIx
                  " (virt 0xBF8%05" HWADDR_PRIx ") = 0x%08" PRIx64
                  " size=%u — unimplemented\n",
                  offset, offset, value, size);
}

static const MemoryRegionOps pic32mk_sfr_stub_ops = {
    .read       = pic32mk_sfr_stub_read,
    .write      = pic32mk_sfr_stub_write,
    .endianness = DEVICE_LITTLE_ENDIAN,
    .valid = {
        .min_access_size = 1,
        .max_access_size = 4,
    },
};

/* ------------------------------------------------------------------ *
 *  Reset module registers                                             *
 *  DS60001519E §7, Table 7-1, Registers 7-1/7-2  (pp. 114-117)      *
 * ------------------------------------------------------------------ */

/*
 * pic32mk_reset_read
 *
 * RCON (offset 0x00 within reset_regs, virtual 0xBF801240):
 *   Returns current reset source flags.
 *   On power-on: POR=1, BOR=1, bits 31-30 read as 1 (reserved).
 *
 * RSWRST (offset 0x10, virtual 0xBF801250):
 *   DS60001519E p.117 Note 2: "Once SWRST bit is set, any read of
 *   RSWRST register will cause a Reset to occur."
 *   We trigger the reset here on read-back if SWRST was armed.
 *
 * RNMICON (offset 0x20), PWRCON (offset 0x30): stub reads.
 */
static uint64_t pic32mk_reset_read(void *opaque, hwaddr offset, unsigned size)
{
    PIC32MKState *s = PIC32MK_MACHINE(opaque);

    switch (offset) {
    case 0x00:   /* RCON  — 0xBF801240 */
        return s->rcon;

    case 0x10:   /* RSWRST — 0xBF801250 */
        /*
         * Datasheet p.117: reading RSWRST after SWRST=1 fires the reset.
         * Real firmware arms SWRST then immediately reads back to trigger.
         */
        if (s->rswrst & RSWRST_SWRST) {
            qemu_log_mask(CPU_LOG_RESET,
                          "pic32mk: RSWRST read-back triggered software reset\n");
            qemu_system_reset_request(SHUTDOWN_CAUSE_GUEST_RESET);
        }
        return s->rswrst;

    case 0x20:   /* RNMICON — 0xBF801260 */
        return s->rnmicon;

    case 0x30:   /* PWRCON  — 0xBF801270 */
        return s->pwrcon;

    default:
        qemu_log_mask(LOG_UNIMP,
                      "pic32mk: reset_read @ offset 0x%" HWADDR_PRIx
                      " — unimplemented\n", offset);
        return 0;
    }
}

/*
 * pic32mk_reset_write
 *
 * RCON:    Firmware clears individual source bits to acknowledge resets.
 *          Hardware-set bits (HS) cannot be cleared by writing 0 here —
 *          they are cleared by hardware on the next reset.  For emulation
 *          we allow software-clear of all user-writable bits.
 *
 * RSWRST:  Requires system unlock sequence on hardware; we skip the unlock
 *          check for emulation simplicity.  Set SWRST=1 to arm.
 *          The actual reset fires on the subsequent read (see above).
 */
static void pic32mk_reset_write(void *opaque, hwaddr offset,
                                uint64_t value, unsigned size)
{
    PIC32MKState *s = PIC32MK_MACHINE(opaque);

    switch (offset) {
    case 0x00:   /* RCON  — software clears reset source flags */
        /*
         * Only the writable user bits can be cleared.
         * Preserve the reserved upper bits (always 1 on read).
         */
        s->rcon = (uint32_t)(value & ~RCON_PWRUP_MASK)
                | (s->rcon & RCON_PWRUP_MASK);
        break;

    case 0x10:   /* RSWRST — arm software reset */
        if (value & RSWRST_SWRST) {
            s->rswrst = RSWRST_SWRST;
            /*
             * Datasheet p.117: the reset is NOT triggered by the write —
             * it fires on the subsequent read.  So we just set the flag.
             */
        }
        break;

    case 0x20:   /* RNMICON */
        s->rnmicon = (uint32_t)value;
        break;

    case 0x30:   /* PWRCON */
        s->pwrcon = (uint32_t)value;
        break;

    default:
        qemu_log_mask(LOG_UNIMP,
                      "pic32mk: reset_write @ offset 0x%" HWADDR_PRIx
                      " = 0x%08" PRIx64 " — unimplemented\n", offset, value);
        break;
    }
}

static const MemoryRegionOps pic32mk_reset_ops = {
    .read       = pic32mk_reset_read,
    .write      = pic32mk_reset_write,
    .endianness = DEVICE_LITTLE_ENDIAN,
    .valid = {
        .min_access_size = 4,
        .max_access_size = 4,
        /*
         * PIC32MK SFRs are 32-bit registers.  Byte/halfword accesses
         * to SFRs are undefined on real hardware; log and allow here.
         */
        .unaligned = false,
    },
    .impl = {
        .min_access_size = 4,
        .max_access_size = 4,
    },
};

/* ------------------------------------------------------------------ *
 *  EVIC Phase 1 stub — INTCON only                                   *
 *  DS60001519E §8, Register 8-1  (p. 159)                            *
 * ------------------------------------------------------------------ */

static uint64_t pic32mk_evic_stub_read(void *opaque, hwaddr offset,
                                       unsigned size)
{
    PIC32MKState *s = PIC32MK_MACHINE(opaque);

    switch (offset) {
    case PIC32MK_OFF_INTCON:   /* 0x0000 */
        return s->intcon;
    default:
        qemu_log_mask(LOG_UNIMP,
                      "pic32mk: EVIC read  @ offset 0x%" HWADDR_PRIx
                      " — unimplemented (Phase 2)\n", offset);
        return 0;
    }
}

static void pic32mk_evic_stub_write(void *opaque, hwaddr offset,
                                    uint64_t value, unsigned size)
{
    PIC32MKState *s = PIC32MK_MACHINE(opaque);

    switch (offset) {
    case PIC32MK_OFF_INTCON:
        s->intcon = (uint32_t)value;
        break;
    default:
        qemu_log_mask(LOG_UNIMP,
                      "pic32mk: EVIC write @ offset 0x%" HWADDR_PRIx
                      " = 0x%08" PRIx64 " — unimplemented (Phase 2)\n",
                      offset, value);
        break;
    }
}

static const MemoryRegionOps pic32mk_evic_stub_ops = {
    .read       = pic32mk_evic_stub_read,
    .write      = pic32mk_evic_stub_write,
    .endianness = DEVICE_LITTLE_ENDIAN,
    .valid   = { .min_access_size = 4, .max_access_size = 4 },
    .impl    = { .min_access_size = 4, .max_access_size = 4 },
};

/* ------------------------------------------------------------------ *
 *  CPU initialisation                                                 *
 * ------------------------------------------------------------------ */

/*
 * pic32mk_cpu_init
 *
 * Instantiates the MIPS CPU.  The microAptiv MCU core is MIPS32r2
 * little-endian.  We use the closest available QEMU type until a
 * dedicated "microAptivUP" type is registered (see effort estimate:
 * "registering the CPU model correctly" is a Tier 1 task).
 *
 * CP0 Config register values come from DS60001519E §3, pp. 55-61:
 *   Config0:  little-endian, MIPS32r2, no TLB        → 0x80200002
 *   Config1:  FPU, EJTAG, perf counters, no TLB      → 0x8000001B
 *   Config3:  VEIC, VINT, DSP2, MCU ASE, microMIPS   → 0x80223FCB
 *   Config4:  Config5 present                         → 0x80000000
 *   Config5:  nested fault                            → 0x00000001
 *   Config7:  WII (WAIT unblocked by interrupt)       → 0x80000000
 */
static void pic32mk_cpu_init(PIC32MKState *s, Error **errp)
{
    Object *cpuobj;

    /*
     * "mips32r2-generic" is the closest type in mainline QEMU to
     * the microAptiv MCU core (MIPS32r2, no TLB, little-endian).
     * TODO Phase 1 stretch: register a "microAptivUP" CPU type that
     * sets the correct CP0 Config values from the #defines above.
     */
    cpuobj = object_new(MIPS_CPU_TYPE_NAME("mips32r2-generic"));
    if (!cpuobj) {
        error_setg(errp, "pic32mk: failed to create MIPS CPU object");
        return;
    }

    /* Little-endian — DS60001519E §3, Register 3-1: CONFIG.BE = 0  */
    object_property_set_bool(cpuobj, "big-endian", false, &error_fatal);

    s->cpu = MIPS_CPU(cpuobj);
    qdev_realize(DEVICE(cpuobj), NULL, errp);
}

/* ------------------------------------------------------------------ *
 *  Memory map initialisation                                          *
 * ------------------------------------------------------------------ */

/*
 * pic32mk_memory_init
 *
 * Builds the physical address map. All addresses from DS60001519E §4.
 *
 * Layout (physical, 1 MB / 256 KB variant):
 *
 *   0x0000_0000 – 0x0003_FFFF   RAM (256 KB)
 *   0x1D00_0000 – 0x1D0F_FFFF   Program Flash (1 MB, two panels)
 *   0x1F80_0000 – 0x1F8F_FFFF   SFR window (1 MB, I/O)
 *   0x1FC0_0000 – 0x1FC0_4FFF   Lower boot alias → Boot Flash 1
 *   0x1FC2_0000 – 0x1FC2_4FFF   Upper boot alias → Boot Flash 2
 *   0x1FC4_0000 – 0x1FC4_57FF   Boot Flash 1 (direct)
 *   0x1FC6_0000 – 0x1FC6_4FFF   Boot Flash 2 (direct)
 *
 * MIPS KSEG0 (0x8000_0000) and KSEG1 (0xA000_0000) are handled by
 * the MIPS memory model in QEMU — we only need physical regions.
 */
static void pic32mk_memory_init(PIC32MKState *s, MemoryRegion *sys_mem,
                                Error **errp)
{
    uint64_t ram_size, flash_size;

    ram_size   = (s->variant == PIC32MK_VARIANT_1024K_256K)
                 ? PIC32MK_RAM_SIZE_256K : PIC32MK_RAM_SIZE_128K;
    flash_size = (s->variant == PIC32MK_VARIANT_1024K_256K)
                 ? PIC32MK_FLASH_SIZE_1024K : PIC32MK_FLASH_SIZE_512K;

    /* -------- RAM -------- */
    memory_region_init_ram(&s->ram, OBJECT(s), "pic32mk.ram",
                           ram_size, errp);
    if (*errp) {
        return;
    }
    memory_region_add_subregion(sys_mem, PIC32MK_RAM_BASE, &s->ram);

    /* -------- Program Flash -------- */
    /*
     * ROM (read-only RAM) — firmware is loaded into this region.
     * DS60001519E Fig 4-2: 1 MB flash is split into two 512 KB panels
     * at 0x1D00_0000 and 0x1D08_0000, but presented as a contiguous
     * region to the CPU.
     */
    memory_region_init_rom(&s->flash, OBJECT(s), "pic32mk.flash",
                           flash_size, errp);
    if (*errp) {
        return;
    }
    memory_region_add_subregion(sys_mem, PIC32MK_FLASH_BASE, &s->flash);

    /* -------- Boot Flash 1 (direct) -------- */
    /*
     * DS60001519E Table 4-1 (p. 72):
     *   0x1FC4_0000 – 0x1FC4_3FFF  user code (16 KB)
     *   0x1FC4_4000 – 0x1FC4_4FFF  sequence/config word space
     *   0x1FC4_5000 – 0x1FC4_57FF  public test flash (device serial,
     *                               ADC calibration, DATAEE cal)
     */
    memory_region_init_rom(&s->boot_flash1, OBJECT(s), "pic32mk.boot1",
                           PIC32MK_BOOT1_SIZE, errp);
    if (*errp) {
        return;
    }
    memory_region_add_subregion(sys_mem, PIC32MK_BOOT1_BASE, &s->boot_flash1);

    /* -------- Boot Flash 2 (direct) -------- */
    memory_region_init_rom(&s->boot_flash2, OBJECT(s), "pic32mk.boot2",
                           PIC32MK_BOOT2_SIZE, errp);
    if (*errp) {
        return;
    }
    memory_region_add_subregion(sys_mem, PIC32MK_BOOT2_BASE, &s->boot_flash2);

    /* -------- Lower boot alias (reset vector region) -------- */
    /*
     * DS60001519E §4, Table 4-1 (p. 72):
     *   Lower boot alias: 0x1FC0_0000 – 0x1FC0_4FFF
     *   This is where KSEG1 0xBFC0_0000 (the MIPS reset vector) maps.
     *   On real hardware it aliases whichever BF has higher TSEQ.
     *   For emulation we alias unconditionally to Boot Flash 1.
     *
     * memory_region_init_alias creates a transparent alias — reads and
     * writes pass through to the target region with an offset applied.
     * Boot Flash 1 starts at 0x1FC4_0000; alias starts at 0x1FC0_0000,
     * so offset = 0x1FC4_0000 − 0x1FC0_0000 = 0x4_0000 → offset = 0
     * within the BF1 MemoryRegion (BF1 is mapped at 0x1FC4_0000).
     */
    memory_region_init_alias(&s->boot_lower_alias, OBJECT(s),
                             "pic32mk.boot-lower-alias",
                             &s->boot_flash1, 0,
                             PIC32MK_BOOT_ALIAS_SIZE);
    memory_region_add_subregion(sys_mem,
                                PIC32MK_BOOT_LOWER_ALIAS,
                                &s->boot_lower_alias);

    /* -------- Upper boot alias -------- */
    /*
     * DS60001519E §4, Table 4-1:
     *   Upper boot alias: 0x1FC2_0000 – 0x1FC2_4FFF → Boot Flash 2
     */
    memory_region_init_alias(&s->boot_upper_alias, OBJECT(s),
                             "pic32mk.boot-upper-alias",
                             &s->boot_flash2, 0,
                             PIC32MK_BOOT_ALIAS_SIZE);
    memory_region_add_subregion(sys_mem,
                                PIC32MK_BOOT_UPPER_ALIAS,
                                &s->boot_upper_alias);

    /* -------- SFR window (1 MB container) -------- */
    /*
     * This is a container region.  Individual peripheral MemoryRegions
     * (UART, SPI, GPIO, etc.) will be added as sub-regions of this
     * container as they are implemented in Phase 2/3.
     *
     * The sfr_stub sits at priority −1, so any real peripheral region
     * added later at the default priority (0) takes precedence.
     */
    memory_region_init(&s->sfr, OBJECT(s), "pic32mk.sfr",
                       PIC32MK_SFR_SIZE);
    memory_region_add_subregion(sys_mem, PIC32MK_SFR_BASE, &s->sfr);

    /* Fallback stub for all unimplemented SFR addresses */
    memory_region_init_io(&s->sfr_stub, OBJECT(s),
                          &pic32mk_sfr_stub_ops, s,
                          "pic32mk.sfr-stub", PIC32MK_SFR_SIZE);
    memory_region_add_subregion_overlap(&s->sfr, 0,
                                        &s->sfr_stub, -1);

    /* -------- Reset module registers -------- */
    /*
     * Covers RCON/RSWRST/RNMICON/PWRCON at offsets 0x1240–0x1270
     * within the CFG block (base 0x1F800000).
     * We map a 64-byte region starting at the RCON offset.
     * Physical address: 0x1F801240, KSEG1: 0xBF801240.
     */
    memory_region_init_io(&s->reset_regs, OBJECT(s),
                          &pic32mk_reset_ops, s,
                          "pic32mk.reset", 0x40);
    memory_region_add_subregion(&s->sfr,
                                PIC32MK_OFF_RCON,
                                &s->reset_regs);

    /* -------- EVIC Phase 1 stub -------- */
    /*
     * Maps the EVIC block at SFR offset 0x10000 (physical 0x1F810000).
     * Only INTCON is implemented for Phase 1; everything else falls
     * through to the generic sfr_stub via the LOG_UNIMP path.
     * Full EVIC (IFSx, IECx, IPCx, OFFx) comes in Phase 2.
     */
    memory_region_init_io(&s->evic_stub, OBJECT(s),
                          &pic32mk_evic_stub_ops, s,
                          "pic32mk.evic-stub",
                          0x2000);   /* covers INTCON through early IPC */
    memory_region_add_subregion(&s->sfr,
                                PIC32MK_EVIC_DMA_BASE - PIC32MK_SFR_BASE,
                                &s->evic_stub);
}

/* ------------------------------------------------------------------ *
 *  System reset handler                                               *
 * ------------------------------------------------------------------ */

/*
 * pic32mk_reset
 *
 * Called by QEMU's reset infrastructure on every system reset
 * (power-on, software reset, watchdog, etc.).
 *
 * Restores the hardware-defined reset state of all emulated registers.
 * DS60001519E §7, Table 7-1 (p. 114) — reset column values.
 */
static void pic32mk_reset(void *opaque)
{
    PIC32MKState *s = PIC32MK_MACHINE(opaque);

    /*
     * RCON reset value: 0xC000_0003
     *   bits 31-30: reserved, read as 1
     *   bit  1: BOR = 1  (Brown-out Reset occurred)
     *   bit  0: POR = 1  (Power-on Reset occurred)
     *
     * DS60001519E §7, Register 7-1 reset column: 0x0003 (low word)
     * + reserved bits 31-30 always 1 → 0xC0000003.
     * Firmware reads RCON to determine reset cause, then clears bits.
     */
    s->rcon    = RCON_RESET_VAL;   /* 0xC0000003 — POR + BOR */
    s->rswrst  = 0x00000000;
    s->rnmicon = 0x00000000;
    s->pwrcon  = 0x00000000;

    /* INTCON reset: 0x00000000 — single-vector mode, MVEC=0 */
    s->intcon  = 0x00000000;
}

/* ------------------------------------------------------------------ *
 *  Firmware loading                                                   *
 * ------------------------------------------------------------------ */

/*
 * pic32mk_load_firmware
 *
 * Loads a raw binary image supplied via -bios into Boot Flash 1.
 *
 * Physical address of Boot Flash 1: 0x1FC4_0000 (PIC32MK_BOOT1_BASE).
 * KSEG1 alias (firmware address): 0xBFC4_0000.
 * Reset vector alias: 0xBFC0_0000 → lower boot alias → BF1[0].
 *
 * For ELF firmware (e.g. compiled with XC32 or mipsel-linux-gnu-gcc
 * with a proper linker script), use -kernel instead of -bios — QEMU
 * handles ELF loading automatically through load_elf().
 *
 * Phase 2 TODO: add ELF loading with load_elf() and entry-point check.
 */
static void pic32mk_load_firmware(MachineState *machine)
{
    const char *firmware = machine->firmware;
    int         size;

    if (!firmware) {
        return;   /* No firmware specified — CPU will execute reset vector */
    }

    /*
     * load_image_targphys writes the binary image to the physical
     * address, populating the ROM MemoryRegion we allocated above.
     */
    size = load_image_targphys(firmware,
                               PIC32MK_BOOT1_BASE,
                               PIC32MK_BOOT1_SIZE);
    if (size < 0) {
        error_report("pic32mk: failed to load firmware '%s'", firmware);
        exit(1);
    }

    qemu_log("pic32mk: loaded %d bytes from '%s' to Boot Flash 1 "
             "(phys 0x%08x, KSEG1 0xBFC40000)\n",
             size, firmware, PIC32MK_BOOT1_BASE);
}

/* ------------------------------------------------------------------ *
 *  Machine init — entry point                                         *
 * ------------------------------------------------------------------ */

/*
 * pic32mk_machine_init
 *
 * Called by QEMU once when the machine is created.  Order matters:
 *   1. Set variant (determines RAM/Flash sizes)
 *   2. Initialise CPU
 *   3. Build memory map
 *   4. Register reset handler
 *   5. Load firmware
 */
static void pic32mk_machine_init(MachineState *machine)
{
    PIC32MKState *s = PIC32MK_MACHINE(machine);
    MemoryRegion *sys_mem = get_system_memory();
    Error *err = NULL;

    /* Default to the larger 1 MB / 256 KB variant */
    s->variant = PIC32MK_VARIANT_1024K_256K;

    /* 1 — CPU */
    pic32mk_cpu_init(s, &err);
    if (err) {
        error_report_err(err);
        exit(1);
    }

    /* 2 — Memory map */
    pic32mk_memory_init(s, sys_mem, &err);
    if (err) {
        error_report_err(err);
        exit(1);
    }

    /* 3 — Reset handler (runs on every system reset) */
    qemu_register_reset(pic32mk_reset, s);

    /* 4 — Apply initial reset state */
    pic32mk_reset(s);

    /* 5 — Firmware */
    pic32mk_load_firmware(machine);
}

/* ------------------------------------------------------------------ *
 *  MachineClass registration                                          *
 * ------------------------------------------------------------------ */

static void pic32mk_machine_class_init(ObjectClass *oc, void *data)
{
    MachineClass *mc = MACHINE_CLASS(oc);

    mc->desc             = "Microchip PIC32MK GPK/MCM with CAN FD (1MB/256KB)";
    mc->init             = pic32mk_machine_init;

    /*
     * Default CPU type — MIPS32r2 little-endian.
     * TODO: replace with "microAptivUP" once the CPU type is registered
     * (Tier 1 task in effort estimate, ~1-2 days).
     */
    mc->default_cpu_type = MIPS_CPU_TYPE_NAME("mips32r2-generic");

    /*
     * RAM size passed through -m is advisory; pic32mk_memory_init
     * uses the variant-defined size.  Set default to match 256 KB.
     */
    mc->default_ram_size = PIC32MK_RAM_SIZE_256K;
    mc->default_ram_id   = "pic32mk.ram";

    mc->is_default       = false;
    mc->min_cpus         = 1;
    mc->max_cpus         = 1;
    mc->default_cpus     = 1;
}

static const TypeInfo pic32mk_machine_info = {
    .name          = TYPE_PIC32MK_MACHINE,
    .parent        = TYPE_MACHINE,
    .instance_size = sizeof(PIC32MKState),
    .class_init    = pic32mk_machine_class_init,
};

static void pic32mk_register_types(void)
{
    type_register_static(&pic32mk_machine_info);
}

type_init(pic32mk_register_types)
