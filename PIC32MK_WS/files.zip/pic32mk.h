/*
 * pic32mk.h — PIC32MK GPK/MCM with CAN FD — shared constants
 *
 * All addresses and register offsets taken directly from:
 *   Microchip DS60001519E, PIC32MK GPK/MCM with CAN FD Family
 *
 * Physical memory map:  §4, Figures 4-1/4-2, Table 4-2  (pp. 70-73)
 * Reset registers:      §7, Table 7-1                   (p. 114)
 * EVIC registers:       §8, Register 8-1 through 8-8    (pp. 159-166)
 * CP0 configuration:    §3, Registers 3-1 through 3-6   (pp. 55-61)
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

#ifndef HW_MIPS_PIC32MK_H
#define HW_MIPS_PIC32MK_H

#include "qemu/units.h"

/* ------------------------------------------------------------------ *
 *  Device variants                                                    *
 * ------------------------------------------------------------------ */
typedef enum {
    PIC32MK_VARIANT_512K_128K,   /* 512 KB Flash, 128 KB RAM */
    PIC32MK_VARIANT_1024K_256K,  /* 1024 KB Flash, 256 KB RAM (default) */
} PIC32MKVariant;

/* ------------------------------------------------------------------ *
 *  Physical memory map                                                *
 *  DS60001519E §4 Figures 4-1 / 4-2  (pp. 70-71)                    *
 * ------------------------------------------------------------------ */

/* RAM — physical base; KSEG0: +0x80000000, KSEG1: +0xA0000000      */
#define PIC32MK_RAM_BASE            0x00000000UL
#define PIC32MK_RAM_SIZE_128K       (128 * KiB)
#define PIC32MK_RAM_SIZE_256K       (256 * KiB)

/* Program Flash — physical; KSEG0: 0x9D000000, KSEG1: 0xBD000000   */
#define PIC32MK_FLASH_BASE          0x1D000000UL
#define PIC32MK_FLASH_SIZE_512K     (512 * KiB)
#define PIC32MK_FLASH_SIZE_1024K    (1024 * KiB)

/*
 * Boot Flash — DS60001519E §4, Table 4-1 (p. 72)
 *
 * Boot Flash 1:  physical 0x1FC4_0000 – 0x1FC4_4FFF  (20 KB user code)
 *                          + 0x1FC4_5000 – 0x1FC4_57FF (2 KB public test)
 *                Seq/Config space at: 0x1FC4_3FB0 – 0x1FC4_3FFC
 *
 * Boot Flash 2:  physical 0x1FC6_0000 – 0x1FC6_3FFF  (16 KB)
 *                Seq/Config space at: 0x1FC6_3FB0 – 0x1FC6_3FFC
 *
 * Lower Boot Alias (reset vector region, 0xBFC0_0000):
 *   Aliased from whichever BF has the higher TSEQ value.
 *   We implement both BF banks + the alias pointing at BF1 by default.
 */
#define PIC32MK_BOOT1_BASE          0x1FC40000UL
#define PIC32MK_BOOT1_SIZE          0x5800UL    /* 20KB code + 2KB test */
#define PIC32MK_BOOT2_BASE          0x1FC60000UL
#define PIC32MK_BOOT2_SIZE          0x5000UL    /* 20 KB */

/*
 * Boot alias regions — lower and upper
 * Lower alias (0x1FC0_0000) is where 0xBFC0_0000 (reset vector) maps.
 * Upper alias (0x1FC2_0000) mirrors Boot Flash 2 (or 1, reversed).
 */
#define PIC32MK_BOOT_LOWER_ALIAS    0x1FC00000UL
#define PIC32MK_BOOT_UPPER_ALIAS    0x1FC20000UL
#define PIC32MK_BOOT_ALIAS_SIZE     0x5000UL

/* ------------------------------------------------------------------ *
 *  SFR base and sub-block bases                                       *
 *  DS60001519E §4, Table 4-2  (p. 73)                                *
 * ------------------------------------------------------------------ */
#define PIC32MK_SFR_BASE            0x1F800000UL  /* Physical SFR window */
#define PIC32MK_SFR_SIZE            0x00100000UL  /* 1 MB total          */

/* KSEG1 (uncached) virtual equivalent — firmware uses this           */
#define PIC32MK_SFR_VBASE           0xBF800000UL

/*
 * Sub-block physical bases, derived from Table 4-2:
 *   virtual 0xBF8x_xxxx → physical 0x1F8x_xxxx
 */
#define PIC32MK_CFG_BASE            0x1F800000UL  /* CFG,PMD,CACHE,NVM,WDT,
                                                    * DMT,ICD,CRU,PPS,HLVD */
#define PIC32MK_EVIC_DMA_BASE       0x1F810000UL  /* EVIC @ +0x0000,
                                                    * DMA  @ +0x1000        */
#define PIC32MK_PERIPH1_BASE        0x1F820000UL  /* Tmr,IC,OC,I2C1-2,
                                                    * SPI1-2,UART1-2,DATAEE,
                                                    * PWM,QEI,CMP,CDAC1,
                                                    * CTMU,PMP               */
#define PIC32MK_PERIPH2_BASE        0x1F840000UL  /* IC10-16,OC10-16,
                                                    * I2C3-4,SPI3-6,
                                                    * UART3-6,CDAC2-3        */
#define PIC32MK_GPIO_BASE           0x1F860000UL  /* PORTA – PORTG          */
#define PIC32MK_CAN_ADC_USB_BASE    0x1F880000UL  /* CAN1-4,ADC,USB1-2      */
#define PIC32MK_RTCC_BASE           0x1F8C0000UL
#define PIC32MK_SSX_BASE            0x1F8F0000UL

/* ------------------------------------------------------------------ *
 *  SFR sub-block offsets within each base                             *
 *  DS60001519E §4, Table 4-2  (p. 73)                                *
 * ------------------------------------------------------------------ */

/* CFG block (from PIC32MK_CFG_BASE) */
#define PIC32MK_OFF_CFG_PMD         0x0000UL
#define PIC32MK_OFF_CACHE           0x0800UL
#define PIC32MK_OFF_FC_NVM          0x0A00UL
#define PIC32MK_OFF_WDT             0x0C00UL
#define PIC32MK_OFF_DMT             0x0E00UL
#define PIC32MK_OFF_ICD             0x1000UL
#define PIC32MK_OFF_CRU             0x1200UL   /* Clock & Reset Unit */
#define PIC32MK_OFF_PPS             0x1400UL   /* Peripheral Pin Select */
#define PIC32MK_OFF_HLVD            0x1800UL

/* Reset registers — offsets from PIC32MK_CFG_BASE                   *
 * DS60001519E §7, Table 7-1  (p. 114)                               */
#define PIC32MK_OFF_RCON            0x1240UL   /* Reset Control          */
#define PIC32MK_OFF_RSWRST          0x1250UL   /* Software Reset         */
#define PIC32MK_OFF_RNMICON         0x1260UL   /* NMI Control            */
#define PIC32MK_OFF_PWRCON          0x1270UL   /* Power Control          */

/* EVIC offsets (from PIC32MK_EVIC_DMA_BASE)                         *
 * DS60001519E §8, Registers 8-1 through 8-8  (pp. 159-166)          */
#define PIC32MK_OFF_INTCON          0x0000UL   /* Interrupt Control      */
#define PIC32MK_OFF_PRISS           0x0010UL   /* Priority Shadow Select */
#define PIC32MK_OFF_INTSTAT         0x0020UL   /* Interrupt Status       */
#define PIC32MK_OFF_IPTMR           0x0030UL   /* Proximity Timer        */
#define PIC32MK_OFF_IFS_BASE        0x0040UL   /* IFS0..IFS7 (8 × 0x10) */
#define PIC32MK_OFF_IEC_BASE        0x00C0UL   /* IEC0..IEC7 (8 × 0x10) */
#define PIC32MK_OFF_IPC_BASE        0x0140UL   /* IPC0..IPC63            */
#define PIC32MK_OFF_OFF_BASE        0x0540UL   /* OFF0..OFF190           */

/* DMA offset (from PIC32MK_EVIC_DMA_BASE) */
#define PIC32MK_OFF_DMA             0x1000UL

/* PERIPH1 block offsets (from PIC32MK_PERIPH1_BASE) */
#define PIC32MK_OFF_TIMER1          0x0000UL
#define PIC32MK_OFF_IC1             0x2000UL
#define PIC32MK_OFF_OC1             0x4000UL
#define PIC32MK_OFF_I2C1            0x6000UL
#define PIC32MK_OFF_SPI1            0x7000UL
#define PIC32MK_OFF_UART1           0x8000UL
#define PIC32MK_OFF_DATAEE          0x9000UL
#define PIC32MK_OFF_PWM1            0xA000UL
#define PIC32MK_OFF_QEI1            0xB200UL
#define PIC32MK_OFF_CMP             0xC000UL
#define PIC32MK_OFF_CDAC1           0xC200UL
#define PIC32MK_OFF_CTMU            0xD000UL
#define PIC32MK_OFF_PMP             0xE000UL

/* PERIPH2 block offsets (from PIC32MK_PERIPH2_BASE) */
#define PIC32MK_OFF_IC10            0x3200UL
#define PIC32MK_OFF_OC10            0x5200UL
#define PIC32MK_OFF_I2C3            0x6400UL
#define PIC32MK_OFF_SPI3            0x7400UL
#define PIC32MK_OFF_UART3           0x8400UL
#define PIC32MK_OFF_CDAC2           0xC400UL

/* CAN/ADC/USB offsets (from PIC32MK_CAN_ADC_USB_BASE) */
#define PIC32MK_OFF_CAN1            0x0000UL
#define PIC32MK_OFF_ADC             0x7000UL
#define PIC32MK_OFF_USB1            0x9000UL

/* ------------------------------------------------------------------ *
 *  RCON register bit definitions                                      *
 *  DS60001519E §7, Register 7-1  (pp. 115-116)                       *
 *                                                                     *
 *  Reset value: 0x0003 (POR=1, BOR=1 on power-on)                    *
 *  Bits 31-30:  Reserved, read as 1 on power-up                       *
 * ------------------------------------------------------------------ */
#define RCON_POR            (1U << 0)   /* Power-on Reset flag        */
#define RCON_BOR            (1U << 1)   /* Brown-out Reset flag       */
#define RCON_IDLE           (1U << 2)   /* Idle mode entry flag       */
#define RCON_SLEEP          (1U << 3)   /* Sleep mode entry flag      */
#define RCON_WDTO           (1U << 4)   /* Watchdog Timer Reset flag  */
#define RCON_DMTO           (1U << 5)   /* Deadman Timer Reset flag   */
#define RCON_SWR            (1U << 6)   /* Software Reset flag        */
#define RCON_EXTR           (1U << 7)   /* External Reset (MCLR) flag */
#define RCON_CMR            (1U << 9)   /* Config Mismatch Reset flag */
#define RCON_BCFGFAIL       (1U << 26)  /* Primary+alt config error   */
#define RCON_BCFGERR        (1U << 27)  /* Primary config error       */
/* Bits 31-30 read as 1 on power-up (reserved) */
#define RCON_PWRUP_MASK     (0xC0000000U)
/* Power-on reset value: POR|BOR + reserved bits set high */
#define RCON_RESET_VAL      (RCON_POR | RCON_BOR | RCON_PWRUP_MASK)

/* RSWRST — DS60001519E §7, Register 7-2  (p. 117)                   *
 * Note: system unlock sequence required before SWRST can be written. *
 * Any READ of RSWRST after SWRST=1 triggers the reset.              */
#define RSWRST_SWRST        (1U << 0)

/* INTCON bit definitions                                             *
 * DS60001519E §8, Register 8-1  (p. 159)                            */
#define INTCON_INT0EP       (1U << 0)   /* INT0 edge polarity         */
#define INTCON_INT1EP       (1U << 1)
#define INTCON_INT2EP       (1U << 2)
#define INTCON_INT3EP       (1U << 3)
#define INTCON_INT4EP       (1U << 4)
#define INTCON_TPC_SHIFT    8
#define INTCON_TPC_MASK     (0x7U << INTCON_TPC_SHIFT)
#define INTCON_MVEC         (1U << 12)  /* Multi-vector mode enable   */
#define INTCON_NMIKEY_SHIFT 24
#define INTCON_NMIKEY_MASK  (0xFFU << INTCON_NMIKEY_SHIFT)
#define INTCON_NMIKEY_VAL   0x4E        /* Magic value triggers NMI   */

/* ------------------------------------------------------------------ *
 *  CP0 configuration register values                                  *
 *  DS60001519E §3, Registers 3-1 through 3-6  (pp. 55-61)            *
 *                                                                     *
 *  These encode the microAptiv MCU hardware capabilities as           *
 *  read-only CP0 fields. QEMU uses these to configure the CPU model.  *
 * ------------------------------------------------------------------ */

/*
 * CP0 Config (Register 16, Select 0)
 *   bit 31: M=1    (Config1 present)
 *   bit 21: SB=1   (SimpleBE)
 *   bit 15: BE=0   (little-endian)
 *   bit 14-13: AT=00 (MIPS32)
 *   bit 12-10: AR=010 (Release 2)
 *   bit 2-0: K0=010 (uncached default; firmware sets to 3)
 */
#define PIC32MK_CP0_CONFIG_VAL      0x80200002U

/*
 * CP0 Config1 (Register 16, Select 1)
 *   bit 31: M=1    (Config2 present)
 *   bit 30-25: MMUSIZE=0 (no TLB)
 *   bit 4: PC=1   (performance counters)
 *   bit 3: WR=1   (no watch registers — reads as 1)
 *   bit 1: EP=1   (EJTAG)
 *   bit 0: FP=1   (FPU present)
 */
#define PIC32MK_CP0_CONFIG1_VAL     0x8000001BU

/*
 * CP0 Config3 (Register 16, Select 3)
 *   bit 31: M=1    (Config4 present)
 *   bit 22-21: IPLW=01 (8-bit IPL width)
 *   bit 17: MCU=1  (MCU ASE)
 *   bit 15-14: ISA=10 (MIPS32+microMIPS, MIPS32 on reset)
 *   bit 13: ULRI=1 (UserLocal register)
 *   bit 12: RXI=1  (RIE/XIE in PageGrain)
 *   bit 11: DSP2P=1 (DSP ASE rev2)
 *   bit 10: DSPP=1  (DSP ASE)
 *   bit 8: ITL=1   (???  — reads 1)
 *   bit 7: VEIC=1  (EIC vectored interrupts)
 *   bit 6: VINT=1  (vectored interrupt mode)
 *   bit 5: SP=0
 *   bit 3: CDMM=1  (Common Device Memory Map)
 */
#define PIC32MK_CP0_CONFIG3_VAL     0x80223FCBU

/*
 * CP0 Config4 (Register 16, Select 4)
 *   bit 31: M=1    (Config5 present)
 */
#define PIC32MK_CP0_CONFIG4_VAL     0x80000000U

/*
 * CP0 Config5 (Register 16, Select 5)
 *   bit 0: NF=1  (nested fault)
 */
#define PIC32MK_CP0_CONFIG5_VAL     0x00000001U

/*
 * CP0 Config7 (Register 16, Select 7)
 *   bit 31: WII=1 (wait IE ignore — WAIT unblocked by interrupt)
 */
#define PIC32MK_CP0_CONFIG7_VAL     0x80000000U

/* ------------------------------------------------------------------ *
 *  CPU and system constants                                            *
 * ------------------------------------------------------------------ */
#define PIC32MK_CPU_FREQ_HZ         120000000UL   /* 120 MHz max        */

/*
 * Reset vector — DS60001519E §8, Table 8-2  (p. 124)
 * "Reset Assertion → branches to 0xBFC0_0000, sets BEV|ERL"
 * Physical: 0x1FC0_0000 (lower boot alias region)
 */
#define PIC32MK_RESET_PC            0xBFC00000UL  /* KSEG1 reset entry  */

/* QEMU type name for this machine */
#define TYPE_PIC32MK_MACHINE        "pic32mk"

/* Number of EVIC IFS/IEC registers (8 × 32-bit = 256 interrupt bits) */
#define PIC32MK_NUM_IRQS            216
#define PIC32MK_NUM_IFSx            8
#define PIC32MK_NUM_IECx            8
#define PIC32MK_NUM_IPCx            64
#define PIC32MK_NUM_OFFx            191   /* OFF0..OFF190 */

#endif /* HW_MIPS_PIC32MK_H */
